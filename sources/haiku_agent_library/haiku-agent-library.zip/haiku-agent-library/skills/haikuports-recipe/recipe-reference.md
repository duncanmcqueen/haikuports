# Recipe reference

Condensed from the HaikuPorts wiki (HaikuPorter-Guidelines, HaikuPorter-BuildRecipes).
Full docs: https://github.com/haikuports/haikuports/wiki

## Variable order
Blank lines separate the groups. Optional entries are marked (opt).

```
SUMMARY
DESCRIPTION
HOMEPAGE
COPYRIGHT
LICENSE
REVISION
srcGitRev (opt, user var)
SOURCE_URI
CHECKSUM_SHA256
SOURCE_FILENAME (opt)
SOURCE_DIR (opt)
PATCHES (opt)
ADDITIONAL_FILES (opt)

ARCHITECTURES
SECONDARY_ARCHITECTURES (opt)
DISABLE_SOURCE_PACKAGE (opt)

commandSuffix / commandBinDir / relativeCommandBinDir (opt, user vars)

libVersion / libVersionCompat (opt, user vars)

GLOBAL_WRITABLE_FILES / USER_SETTINGS_FILES (opt)
POST_INSTALL_SCRIPTS / PRE_UNINSTALL_SCRIPTS (opt)
PACKAGE_USERS / PACKAGE_GROUPS (opt)

PROVIDES
REQUIRES
CONFLICTS / REPLACES / SUPPLEMENTS / FRESHENS (opt)

PROVIDES_devel
REQUIRES_devel

BUILD_REQUIRES
BUILD_PREREQUIRES

TEST_REQUIRES (opt)

defineDebugInfoPackage (opt)

PATCH() (opt)
BUILD() (opt)
INSTALL()
TEST() (opt)
```

## ARCHITECTURES
Space-separated list. Prefix `?` = untested, `!` = broken. `all` sets every arch and can be
overridden after it.

- `ARCHITECTURES="all !x86_gcc2"`: everything except gcc2
- `ARCHITECTURES="x86_gcc2 ?x86 !ppc"`: works on gcc2, untested on x86, broken on ppc
- `any` = no arch-specific binaries (scripts); `source` = source-only package

Ports that need a modern compiler use `"all !x86_gcc2"` plus `SECONDARY_ARCHITECTURES="x86"`
so 32-bit Haiku can still get them as a hybrid package.

## Hybrid builds
`$secondaryArchSuffix` is empty on a primary build and `_x86` on a secondary build. Use it on
package names, `lib:`/`devel:` entries, and toolchain commands (`cmd:gcc$secondaryArchSuffix`,
`cmd:ld$...`, `cmd:pkg_config$...`). Mixing architectures causes missing-library or
missing-symbol errors. `$portName` also carries the suffix, so avoid it in `SOURCE_DIR`,
`SOURCE_FILENAME`, and `PATCHES` for hybrid ports.

Per-arch logic uses `$effectiveTargetArchitecture` or `$targetArchitecture`:
```
if [ "$effectiveTargetArchitecture" = x86 ]; then
	PATCHES+="
		foo_x86-$portVersion.patchset
		"
fi
```

## Directory variables (use instead of hardcoded paths)
`$prefix`, `$binDir`, `$libDir`, `$includeDir`, `$dataDir`, `$docDir`, `$manDir`,
`$developDir`, `$developLibDir`, `$portVersion`, `$jobArgs` (pass to make).

## Helper functions
- `runConfigure [--omit-dirs <dirs>] ./configure <args>`: runs configure with the correct
  Haiku directory arguments.
- `packageEntries <suffix> <paths...>`: move entries into a sibling package
  (e.g. `packageEntries devel $developDir`).
- `prepareInstalledDevelLib <libBase>` / `prepareInstalledDevelLibs <libBase...>`: symlink
  shared libs into `$developLibDir` and move static libs there.
- `fixPkgconfig`: move pkgconfig files to the develop dir and fix their paths.
- `fixDevelopLibDirReferences`: fix references to the develop lib dir.
- `defineDebugInfoPackage <pkg> <binaries...>`: split debug symbols into a `_debuginfo`
  package.
- `addAppDeskbarSymlink` / `addPreferencesDeskbarSymlink`: add Deskbar menu entries.

## Library versioning
```
libVersion="5.1.10"
libVersionCompat="$libVersion compat >= ${libVersion%%.*}"

PROVIDES="
	foo$secondaryArchSuffix = $portVersion
	lib:libfoo$secondaryArchSuffix = $libVersionCompat
	"
```

## Commands for ports that skip gcc2
If a port provides `cmd:` entries and is broken on `x86_gcc2` but builds on secondary `x86`,
define `commandSuffix`, `commandBinDir`, and `relativeCommandBinDir` per the wiki's
"Using the commandBinDir user variable" section, so the commands land in the primary bin dir.

## Policy
- Applications that statically link a web engine are banned. Dynamically linking a separate
  engine package (HaikuWebKit, QtWebEngine) is allowed.
- Patches are a last resort; try to upstream.
