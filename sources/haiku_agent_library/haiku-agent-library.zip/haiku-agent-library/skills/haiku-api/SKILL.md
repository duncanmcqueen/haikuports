---
name: haiku-api
description: Native Haiku/BeOS C++ API (BApplication, BLooper, BWindow, BView, BMessage, Layout API, Storage Kit, Locale Kit). Use when writing or reviewing native Haiku GUI or system code, or porting BeOS code.
---

# Haiku native API

The full Haiku Book (API reference) is bundled in `./haiku-book/`. Do not read it whole.
1. Check `./haiku-book/INDEX.md` to find the kit and class.
2. Grep for what you need, e.g. `grep -n "\\\\fn.*PostMessage" haiku-book/app/Looper.dox`
3. Read only the matching section. Kit overviews are the `_*_intro.dox` files.
On a Haiku machine, the real headers are in `/boot/system/develop/headers/os/`.
For BeOS-era classes the Book doesn't cover, the legacy Be Book is at
https://www.haiku-os.org/legacy-docs/bebook/ (online only).

## Core model (get this right first)
- **One BApplication per app**, constructed with a MIME signature like
  `"application/x-vnd.Vendor-AppName"`. `Run()` enters its message loop on the calling
  thread.
- **Every BLooper has its own thread**, and every BWindow is a BLooper, so each window
  runs in its own thread. Handlers (BView, BHandler) belong to one looper.
- **Talk across threads with messages**, not shared state. Send a `BMessage` through a
  `BMessenger` or `PostMessage()`; handle it in `MessageReceived()` and pass unknown
  `what` codes to the base class.
- **Lock before touching another looper's objects.** Calling into a window's views from
  another thread needs `LockLooper()`/`Lock()` and a matching unlock. Prefer messaging.
- **Never `delete` a looper or window.** Post `B_QUIT_REQUESTED` or call `Quit()` from its
  own thread; it deletes itself. Override `QuitRequested()` to veto or clean up.
- **Views draw in `Draw()`** on the window thread. Request redraws with `Invalidate()`.
  Do setup that needs the window in `AttachedToWindow()`, not the constructor.
- **Use the Layout API** (`BLayoutBuilder::Group<>`, `Grid<>`, `Split<>`) instead of fixed
  BRect frames so UIs handle font sizes and localization.

## Files and paths
- Never hardcode `/usr`, `/etc`, or home paths. Use `find_directory()` with constants like
  `B_USER_SETTINGS_DIRECTORY` (see `haiku-book/storage/FindDirectory.dox`).
- Files are named by `entry_ref` (survives renames). Use `BEntry`, `BPath`, `BFile`, and
  `BNode` for attributes. Extended attributes and `BQuery` are first-class: use them for
  metadata instead of sidecar files.

## Common building blocks
- Strings: `BString`. Lists: `BObjectList`/`BList`. Errors: `status_t`, check `B_OK`.
- Localization: `B_TRANSLATE("text")` with `B_TRANSLATION_CONTEXT` defined per file
  (Locale Kit, `haiku-book/locale/`).
- Notifications: `BNotification`. Alerts: `BAlert` (call `Go()`).
- Settings: flatten a `BMessage` to a file in the settings directory.

## Linking
`libbe` covers App, Interface, Storage, and Support kits. Others are separate, such as
`libtranslation`, `libmedia`, `libnetwork`, `libgame`, `libdevice`, and `libtracker`.
Check the `Corresponds to:` header in each .dox file for the header path, and grep an
existing HaikuPorts recipe or Haiku app for the exact library name if unsure.

## BeOS vs Haiku
Read `haiku-book/compatibility.dox` when porting BeOS code. Notable: the header path is
`os/`, not `be/`.

The bundled docs are MIT-licensed (Haiku, Inc.); see each file's header.
`haiku-book/SOURCE_REVISION.txt` records the haiku commit they came from. Refresh by
re-copying `docs/user` from https://github.com/haiku/haiku.
