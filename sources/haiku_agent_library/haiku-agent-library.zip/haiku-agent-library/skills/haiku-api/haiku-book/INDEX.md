# Haiku Book index

Generated from haiku/docs/user. Grep these .dox files for `\class BName`,
`\fn` signatures, or a topic word. Online: https://api.haiku-os.org/classB<Name>.html

- **app/**: Application, Clipboard, Cursor, Handler, Invoker, Key, KeyStore, LaunchRoster, Looper, Message, MessageFilter, MessageQueue, MessageRunner, Messenger, Notification, PropertyInfo, Roster, _app_intro, _app_keystore, _app_messaging, _launch_intro
- **device/**: Joystick, SerialPort, USBKit
- **drivers/**: KernelExport, USB3, USB_spec, fs_interface, fs_modules, synchronization_primitives, usb_modules
- **game/**: DirectWindow, FileGameSound, GameProducer, GameSound, SimpleGameSound
- **graphics/**: Accelerant
- **interface/**: AbstractLayout, AbstractLayoutItem, AffineTransform, Alert, Alignment, Bitmap, Box, Button, CardLayout, CardView, ChannelControl, ChannelSlider, CheckBox, ColorControl, Control, Deskbar, Dragger, Font, Gradient, GradientConic, GradientDiamond, GradientLinear, GradientRadial, GradientRadialFocus, GraphicsDefs, GridLayout, GridLayoutBuilder, GridView, GroupLayout, GroupLayoutBuilder, GroupView, IconUtils, Input, InterfaceDefs, Layout, LayoutBuilder.Cards, LayoutBuilder.Grid, LayoutBuilder.Group, LayoutBuilder.Split, LayoutBuilder, LayoutItem, ListItem, ListView, Menu, MenuBar, MenuField, MenuItem, OptionControl, OptionPopUp, OutlineListView, Picture, PictureButton, Point, Polygon, PopUpMenu, RadioButton, Rect, Region, Screen, ScrollBar, ScrollView, SeparatorItem, SeparatorView, Shape, Shelf, Size, SpaceLayoutItem, SplitLayoutBuilder, SplitView, StatusBar, StringItem, StringView, TabView, TextControl, TextView, ToolTip, TwoDimensionalLayout, View, Window, _interface_intro, _layout_intro
- **kernel/**: condition_variable, image
- **locale/**: Catalog, Collator, Country, DateFormat, DateTimeFormat, DurationFormat, Locale, LocaleRoster, NumberFormat, TimeFormat, TimeZone, UnicodeChar
- **mail/**: MailAttachment, MailComponent, MailDaemon, TextMailComponent, mail_encoding
- **media/**: Buffer, FileInterface
- **net/**: AbstractSocket, Certificate, DatagramSocket, NetworkAddress, NetworkDevice, NetworkNotifications, NetworkRoster, NetworkRoute, ProxySecureSocket, SecureSocket, Socket, _network_intro
- **netservices/**: ErrorsExt, ExclusiveBorrow, HttpFields, HttpRequest, HttpResult, HttpSession, HttpTime, NetServicesDefs
- **posix/**: _libroot, dlfcn, syslog, unistd
- **shared/**: MemoryRingIO, _libshared
- **storage/**: AppFileInfo, Directory, Entry, EntryList, File, FilePanel, FindDirectory, Mime, MimeType, Node, NodeInfo, NodeMonitor, Path, PathFinder, Query, Resources, Statable, SymLink, Volume, VolumeRoster, _libtracker, fs_query
- **support/**: Architecture, Archivable, Autolock, Beep, BlockCache, BufferIO, BufferedDataIO, DataIO, DateTime, Flattenable, Job, List, Locker, ObjectList, Referenceable, StopWatch, String, StringList, SupportDefs, TLS, TypeConstants, Url, parsedate, support_intro
- **translation/**: BitmapStream, Translator, TranslatorRoster
