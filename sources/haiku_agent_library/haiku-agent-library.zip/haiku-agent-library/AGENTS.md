# Haiku OS development

You are working on code for Haiku (the open-source BeOS successor), usually ported from Linux.

## Ground rules
- Haiku is not Linux. Never assume glibc, systemd, /proc, /usr, or Linux-only syscalls exist.
- The filesystem is package-managed and read-only under /boot/system. Installs go through
  packages (.hpkg); local unpackaged files go in ~/config/non-packaged/.
- Use `finddir` / find_directory() for standard paths. Never hardcode /usr or /etc.
- Networking lives in libnetwork (not libsocket/libnsl). BSD extras live in libbsd.
- Prefer upstreaming a fix over carrying a Haiku-only patch.
- When unsure how Haiku handles something, grep the local haikuports tree for prior art
  before guessing: other ports have usually solved it already.

## Where to look
- HaikuPorts tree: ~/haikuports (recipes in <category>/<port>/, patchsets in patches/)
- HaikuPorter tool: ~/haikuporter
- API docs: https://api.haiku-os.org (Haiku Book), legacy BeBook for older kits

## Skills
- `haikuports-recipe`: writing, building, patching, or submitting a HaikuPorts recipe.
- `haiku-api`: native C++ API (BApplication, BWindow, BMessage, layouts, Storage Kit).

## Style
- Recipes: tabs for indentation, 100-character lines, follow the haikuports-recipe skill.
- C/C++ for Haiku itself: follow Haiku's coding guidelines (tabs, 100 columns).
