# Haiku agent library

Context for coding agents (Maki, Pi, and anything else that reads AGENTS.md and
Agent Skills) working on Haiku OS code.

## Layout
```
AGENTS.md                         always-on rules (keep short)
skills/haikuports-recipe/         loaded on demand
  SKILL.md                        workflow + reviewer rules
  recipe-reference.md             variable order, helpers, arch syntax
  template.recipe                 starting point for new recipes
skills/haiku-api/
  SKILL.md                        core API model + how to search the Book
  haiku-book/                     Haiku Book sources (.dox, MIT), grep-able
    INDEX.md                      kit -> class map
```

## Install in Pi on Haiku
```
# Pi 1.x needs Node >= 22.19
node -v

# npm global installs must go to non-packaged (system dirs are read-only)
npm config set prefix ~/config/non-packaged
npm install -g @earendil-works/pi-coding-agent

# Register the library as a Pi package (loads skills/ in place, no copy)
unzip haiku-agent-library.zip -d ~
pi install ~/haiku-agent-library

# On a Haiku box every project is Haiku work, so global rules are fine
mkdir -p ~/.pi/agent
cat ~/haiku-agent-library/AGENTS.md >> ~/.pi/agent/AGENTS.md
```
Check it in Pi with `/skill:haiku-api`.

## Install elsewhere
Clone this folder somewhere stable (e.g. ~/haiku-agent-library), then:

```
# Skills: both Maki and Pi read ~/.agents/skills/
mkdir -p ~/.agents/skills
ln -s ~/haiku-agent-library/skills/haikuports-recipe ~/.agents/skills/haikuports-recipe

# Rules: per project is best, so Haiku rules don't leak into non-Haiku work
ln -s ~/haiku-agent-library/AGENTS.md ~/haikuports/AGENTS.local.md   # Maki
# For Pi, put or symlink AGENTS.md in the project dir or a parent of it
```

Maki loads `AGENTS.md` (or `AGENTS.local.md`) from the git root down to the cwd, plus a
global `~/.config/maki/AGENTS.md`. Pi loads `AGENTS.md` from `~/.pi/agent/`, parent
directories, and the cwd. Only use the global locations if every project you open with
that agent is Haiku work.

## Adding skills
One folder per topic with a `SKILL.md` whose `description` says exactly when to use it.
Put long material in sibling files and link them from SKILL.md (Maki only auto-reads
SKILL.md). Planned: haiku-posix-porting, haiku-debugging.
