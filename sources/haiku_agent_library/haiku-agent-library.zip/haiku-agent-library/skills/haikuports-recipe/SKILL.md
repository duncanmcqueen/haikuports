---
name: haikuports-recipe
description: Write, build, patch, lint, or submit a HaikuPorts .recipe for Haiku OS with haikuporter, including creating patchsets and preparing a pull request to haikuports/haikuports.
---

# HaikuPorts recipe workflow

Use this when creating or updating a port in the HaikuPorts tree. For the full variable
order, helper functions, and architecture syntax, read `./recipe-reference.md`.
Start new recipes from `./template.recipe`.

## Before writing anything
1. Find prior art. Search the tree for an existing recipe for this or a similar project:
   `find ~/haikuports -maxdepth 3 -name '*.recipe' | grep -i <name>`
   An older version of the same port is the best starting point: copy it, bump the
   version, and reuse its patchsets as the base.
2. Pick the category from Gentoo Portage's layout (e.g. `net-libs/`, `dev-lang/`).
   Reuse the existing directory if the port is already there.
3. Name the file `<port_name>-<version>.recipe`: lowercase, underscores instead of dashes
   in the name (e.g. `cool_app-1.0.2.recipe`). Versioned runtimes may carry the major in
   the name (e.g. `nodejs20-20.15.1.recipe`).

## Build loop
Run on Haiku from the haikuports tree:

```
haikuporter -S -j$(nproc) --no-source-packages --get-dependencies <port>
```

- `-S` enforces strict packaging policy. Always build with it before submitting.
- On failure the work dir is kept: `<port-dir>/work-<version>/sources/...`
- `haikuporter --lint <port>` checks the recipe without building.
- `haikuporter -E <port>` enters the build chroot to reproduce a failure by hand.
- `haikuporter --test <port>` runs the recipe's `TEST()`.
- `haikuporter -w <port>` explains why a dependency is pulled in.

## Making a patchset
Sources in the work dir are a git repo with the original tarball committed.
1. Fix the source under `work-<version>/sources/<srcdir>/`.
2. In that directory: `git add <files> && git commit` with a short, specific message
   ("Search for gethostbyname in libnetwork"). One logical fix per commit.
3. Back at the port: `haikuporter -e <port>` writes `patches/<port>-<version>.patchset`.
4. Add `PATCHES="<port>-$portVersion.patchset"` to the recipe.
5. Rebuild from scratch: `haikuporter -S --force <port>` to prove the patchset applies.

When carrying patches forward from an older version, apply the old patchset in the new
work dir (`git am`), fix conflicts, drop anything upstream has merged, then re-extract.

## Recipe rules that reviewers enforce
- Variables in the documented order (see reference). Lines max 100 chars, except URLs and
  checksums. Indent with tabs.
- `SUMMARY`: one line, <= 70 chars, no trailing period, no package name, no "for Haiku",
  no implementation language.
- `DESCRIPTION`: 2+ sentences, unindented, each line ends with `\`. Include search terms
  a user would type into HaikuDepot.
- `HOMEPAGE`: trailing slash only for bare domains or when the site redirects to one.
- `REVISION`: starts at "1"; bump only when the built package changes, not for
  recipe-only edits like extra mirrors.
- Library `PROVIDES` versions match the .so version: `lib:libfoo = 5.1.10 compat >= 5`.
- Sort `PROVIDES`/`REQUIRES`/`BUILD_REQUIRES`/`BUILD_PREREQUIRES` alphabetically, with
  `haiku` / `haiku_devel` first.
- Use `$secondaryArchSuffix` on every lib, devel, and toolchain entry
  (`cmd:gcc$secondaryArchSuffix`) so hybrid x86 builds work.
- Define a debuginfo package with `defineDebugInfoPackage` where practical.
- Use `SOURCE_DIR` instead of `cd` into the main source dir. Use `mkdir -p`.
- Prefer upstreaming fixes; patches are for what upstream will not take.

## Common porting fixes
- Undefined socket/DNS symbols: link `-lnetwork`.
- Missing BSD functions (e.g. strlcpy variants, err.h helpers): link `-lbsd`.
- Missing backtrace(): depend on `libexecinfo`.
- configure scripts that don't know Haiku: regenerate with `autoreconf -fi` in BUILD().
- Paths: route through `runConfigure` or the recipe directory variables
  (`$prefix`, `$libDir`, `$includeDir`, `$dataDir`), never hardcoded /usr.
- Unknown platform macros: Haiku defines `__HAIKU__`; check for it, not `__linux__`.

## Submitting
1. Build clean with `-S --force` on x86_64 (and note results for x86/x86_gcc2 in
   `ARCHITECTURES` using `?` untested / `!` broken).
2. Commit only the recipe and its patchsets. Commit message: `<port>: new recipe` or
   `<port>: bump to <version>`.
3. Open a PR against haikuports/haikuports. Say what you tested and on which arch.
